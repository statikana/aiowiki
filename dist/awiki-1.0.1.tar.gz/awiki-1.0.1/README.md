# awiki

A basic asynchronous wrapper for the wikimedia API